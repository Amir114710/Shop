from django.apps import AppConfig


class SmsSendConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "sms_send"
    verbose_name = 'ارسال sms'
