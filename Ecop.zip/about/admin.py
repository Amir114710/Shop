from django.contrib import admin
from .models import AboutModel , PosterAbout , PropertyShop


admin.site.register(AboutModel)
admin.site.register(PosterAbout)
admin.site.register(PropertyShop)
