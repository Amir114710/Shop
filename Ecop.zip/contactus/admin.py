from django.contrib import admin
from .models import ContactUsModels , Contacts

admin.site.register(ContactUsModels)
admin.site.register(Contacts)
